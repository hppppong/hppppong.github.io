/// <reference types="react-scripts" />

declare module "react-qr-scanner";
declare module "react-webcam-qr-scanner";
